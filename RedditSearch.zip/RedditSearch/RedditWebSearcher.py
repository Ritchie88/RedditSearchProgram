#Ryan Ritchie
#Reddit Web Scraper, asks the user for a word to search for, searhes the subreddit given by the user, then the keyword from the user of reddit to find related pages


import praw
#asks the user for the subreddit title to search in, as well a keyword to find related posts to
def askUser():
	#loop until data is given
	while(True):
		subredditSearch = input("Enter the subreddit to search in: ");
		searchString = input("\nEnter keywords to search For: ");
		#if user entered both pieces of info, leave function
		if(searchString != "" and subredditSearch != ""):
			break;
	return subredditSearch,searchString;
		

def main():
	searchString= "";
	subredditSearch = "";
	#collect user info
	subredditSearch, searchString = askUser();
	#make the connection to reddit
	#TO USE: Enter information required by reddit to access the API below
	reddit = praw.Reddit(client_id = 'ENTER INFO',client_secret = 'ENTER INFO',
						user_agent = 'ENTER INFO',username = 'ENTER INFO',password = 'ENTER INFO');
	#get the subreddit and it's top posts
	subreddit = reddit.subreddit(subredditSearch);
	topPosts = subreddit.top(limit = 200);
	#go through the posts
	for currentPost in topPosts:
		#print(currentPost.title);
		tempList = currentPost.title.split(' ');
		#check each word in the post tile, if matching, display post info to the user
		for word in tempList:
			if(word.lower() == searchString.lower()):
				print("\nFound Related Post:\n\nTitle of Post:\n\n" + currentPost.title + "\n\nPost URL: \n\n" + currentPost.url + "\n");
		
main();